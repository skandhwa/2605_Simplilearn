import login from "../PageObjects/LoginPage"
import HomePage from "../PageObjects/HomePage"
describe('POMDemo', () => {
    it('passes', () => {
      cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
       const xyz=new login();
       const abc=new HomePage();
       xyz.setUserName("Admin");
       xyz.setPassword("admin123");
       xyz.clickSubmit();
       abc.ClickAdmin();
       

       

      
   
    })
  })


