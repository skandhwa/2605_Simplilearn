describe('template spec', () => {


  it.only('passes', () => {
    cy.visit('https://example.cypress.io')
  })

  it.skip('passes', () => {
    cy.visit('https://example.cypress.io')
  })

  it.only('passes', () => {
    cy.visit('https://example.cypress.io')
  })

  it.only('passes', () => {
    cy.visit('https://example.cypress.io')
  })




})