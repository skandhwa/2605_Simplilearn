describe('All Controls in page', () => {
    it('Validate all controls', () => {
      cy.visit('https://nxtgenaiacademy.com/demo-site/')
      cy.xpath("//input[@id='vfb-5']").type("Saurabh")
      cy.xpath("//input[@id='vfb-31-1']").should('be.visible').click();
      cy.xpath("//input [@id='vfb-20-0']").check().should('be.checked')
      cy.xpath("//input[@class='select2-search__field']").select('India').should('have.value','India')
      cy.wait(5000)
      cy.xpath("//input [@id='vfb-20-0']").uncheck().should('not.be.checked')
      cy.xpath("(//span[@class='select2-selection select2-selection--single'])[1]").select('India').should('have.value','India')


    })
  })