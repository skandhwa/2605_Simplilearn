describe('AutoSuggestionDropdown', () => {
    it('passes', () => {
      cy.visit('https://www.wikipedia.org/')
      cy.xpath("//input[@id='searchInput']").type('Delhi')
      cy.get('.suggestion-title').contains('Delhi Metro').click()
      
      
   
    })
  })