import 'cypress-file-upload'

describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://the-internet.herokuapp.com/upload')
      cy.wait(3000)
      cy.xpath("//input[@id='file-upload']").attachFile('Cypress Setup.txt')
      cy.xpath("//input[@id='file-submit']").click();
      cy.wait(5000)
      cy.xpath("//h3[text()='File Uploaded!']").should('have.text','File Uploaded!')

    })
  })