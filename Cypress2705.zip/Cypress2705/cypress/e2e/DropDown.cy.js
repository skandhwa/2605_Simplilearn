describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://www.tutorialspoint.com/selenium/selenium_automation_practice.htm')
      cy.wait(3000)
      cy.scrollTo(0, 250)
      cy.xpath("//select[@name='continents']").select('Africa').should('have.value','Africa')
    })
  })