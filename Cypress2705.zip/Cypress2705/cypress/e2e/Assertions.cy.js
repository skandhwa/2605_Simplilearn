describe('Implicit Assertions', () => {
    it('Using Implicit Assertion', () => {
      cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
      cy.url().should('include','orange')
      cy.url().should('eq','https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
      cy.url().should('include','orangehrm').and('eq','https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
      .and('contain','orange').and('not.contain','green');
      cy.xpath("//input[@name='username']").type("Admin")
      cy.xpath("//input[@name='password']").type("admin123")
      cy.xpath("//button[@type='submit']").click()
      let expName="tajpalace Swami"

      cy.get(".oxd-userdropdown-name").then
      ( (x)=> {
            let actName=x.text()
            expect(actName).to.equal(expName)

       assert.equal(actName,expName)

      })


    })
  })