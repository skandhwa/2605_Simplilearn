class login{
    setUserName(username)
    {
        cy.xpath("//input[@name='username']").type(username)
    }
    setPassword(password)
    {
        cy.xpath("//input[@name='password']").type(password)
    }

    clickSubmit()
    {
        cy.xpath("//button[@type='submit']").click()
    }


    

}
export default login;