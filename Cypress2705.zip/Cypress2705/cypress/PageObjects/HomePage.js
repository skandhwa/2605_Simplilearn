class HomePage{
    ClickAdmin()
    {
        cy.xpath("//a[@class='oxd-main-menu-item active']").click()
    }
}

export default HomePage;